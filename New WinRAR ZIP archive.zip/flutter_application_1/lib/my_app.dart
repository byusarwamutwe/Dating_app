import 'package:flutter_application_1/app/locator.dart';
import 'package:flutter_application_1/services/navigation_service.dart';
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter/material.dart';

import './app/app_router.dart' as router;
import './app/data/app_route.dart' as routes;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      useInheritedMediaQuery: true,
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: kAppName,
          theme: ThemeData(
            // scaffoldBackgroundColor: Color(kLight.value),
            iconTheme: IconThemeData(color: Color(kDarkRed.value)),
          ),
          onGenerateRoute: router.generateRoute,
          initialRoute: routes.startup,
          navigatorKey: locator<NavigationService>().navigatorKey,
        );
      },
    );
  }
}
