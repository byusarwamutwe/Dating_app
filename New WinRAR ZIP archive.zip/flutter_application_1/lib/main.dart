import 'package:flutter_application_1/app/locator.dart';
import 'package:flutter_application_1/bloc/onboarding/onboarding_bloc.dart';
import 'package:flutter_application_1/my_app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  setupLocator();
  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => OnboardingBloc()),
      ],
      child: const MyApp(),
    ),
  );
}
