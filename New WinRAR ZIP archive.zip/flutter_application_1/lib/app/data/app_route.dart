const String startup = '/';
const String onboarding = '/onboarding';
const String login = '/login';
const String signup = '/signup';
const String otp = '/otp';
