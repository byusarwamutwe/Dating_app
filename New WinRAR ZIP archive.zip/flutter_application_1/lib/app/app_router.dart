import './data/app_route.dart' as routes;
import 'exports.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case routes.startup:
      return MaterialPageRoute(builder: (context) => StartupScreen());
    case routes.onboarding:
      return MaterialPageRoute(builder: (context) => OnBoardingScreen());
    case routes.login:
      return MaterialPageRoute(builder: (context) => LoginScreen());
    case routes.signup:
      return MaterialPageRoute(builder: (context) => SignUpScreen());
    case routes.otp:
      final email = settings.arguments as String;
      return MaterialPageRoute(builder: (context) => OtpScreen(email: email));
    default:
      return MaterialPageRoute(
        builder: (context) => Scaffold(
          body: Center(
            child: Text('No path for ${settings.name}'),
          ),
        ),
      );
  }
}
