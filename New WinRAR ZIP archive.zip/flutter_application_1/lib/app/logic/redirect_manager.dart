import 'package:flutter_application_1/app/exports.dart';

abstract class NavigationRedirectsManager {
  static String? baseRedirect(BuildContext context, GoRouterState state) {
    return null;
  }
}
