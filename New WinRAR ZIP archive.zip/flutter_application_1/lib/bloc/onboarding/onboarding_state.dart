part of 'onboarding_bloc.dart';

class OnBoardingState {
  int page;
  OnBoardingState({this.page = 0});
}
