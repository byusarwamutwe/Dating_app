part of 'onboarding_bloc.dart';

class OnBoardingEvent{}
