import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/widgets/reusable_text.dart';
import 'package:flutter/material.dart';

class CustomTxtField extends StatefulWidget {
  const CustomTxtField({
    super.key,
    required this.hintText,
    required this.keyboardType,
    this.validator,
    required this.labelText,
    this.isValidationMessage = false,
    this.validationMessage,
    required this.inputController,
    this.suffixIcon = false,
  });
  final String hintText;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final String labelText;
  final bool isValidationMessage;
  final String? validationMessage;
  final TextEditingController inputController;
  final bool? suffixIcon;

  @override
  State<CustomTxtField> createState() => _CustomTxtFieldState();
}

class _CustomTxtFieldState extends State<CustomTxtField> {
  bool passwordvisibility = false;
  @override
  Widget build(BuildContext context) {
    final inputBorder = OutlineInputBorder(
      borderRadius: knormalBorderRadius,
      borderSide: BorderSide(color: Color(kDarkGrey.value), width: 1.5),
    );
    final errorBorder = OutlineInputBorder(
      borderRadius: kminiMediumBorderRadius,
      borderSide: BorderSide(color: Color(kDarkRed.value), width: 1.5),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ReusableText(
          text: widget.labelText,
          style: appMStyle(
            17,
            Color(kDark.value),
            FontWeight.w500,
          ),
        ),
        TextFormField(
          controller: widget.inputController,
          keyboardType: widget.keyboardType,
          obscureText: widget.suffixIcon == true ? !passwordvisibility : false,
          style: appMStyle(
            17,
            Color(kDark.value),
            FontWeight.w500,
          ),
          validator: widget.validator,
          decoration: InputDecoration(
            // filled: true,
            // fillColor: Color(kDarkWithOp.value),
            hintText: widget.hintText,
            suffixIcon: widget.suffixIcon == true
                ? IconButton(
                    onPressed: () => setState(
                      () => passwordvisibility = !passwordvisibility,
                    ),
                    icon: Icon(
                      passwordvisibility
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      // color: AppColors.neutralColor.shade700,
                      size: 18,
                    ),
                  )
                : null,
            hintStyle: appMStyle(17, Color(kDark.value), FontWeight.w500),
            disabledBorder: inputBorder,
            enabledBorder: inputBorder,
            focusedErrorBorder: errorBorder,
            errorBorder: errorBorder,
            focusedBorder: inputBorder,
          ),
        ),
        ReusableText(
          text: widget.isValidationMessage == true
              ? widget.validationMessage ?? ''
              : '',
          style: appMStyle(17, Color(kBrightRed.value), FontWeight.w500),
        )
      ],
    );
  }
}
