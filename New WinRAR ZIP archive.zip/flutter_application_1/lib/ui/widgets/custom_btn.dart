import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/exports.dart';
import 'package:flutter/material.dart';

class CustomBtn extends StatelessWidget {
  const CustomBtn({
    super.key,
    this.width,
    this.height,
    this.text,
    this.onTap,
    required this.color,
    this.textColor,
    this.resize = false,
    this.icon,
  });
  final double? width;
  final double? height;
  final String? text;
  final void Function()? onTap;
  final Color color;
  final Color? textColor;
  final bool resize;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: resize ? klargeBorderRadius : kmediumBorderRadius,
        ),
        child: resize
            ? Icon(icon, size: 23.sp, color: Color(kLight.value))
            : const Center().reusableText(
                text ?? '',
                style: appMStyle(
                  20,
                  textColor ?? Colors.white,
                  FontWeight.w700,
                ),
              ),
      ),
    );
  }
}
