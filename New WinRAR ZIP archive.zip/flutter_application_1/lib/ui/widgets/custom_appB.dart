import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/utils/asset_manager.dart';
import 'package:flutter/material.dart';

class CustomAppB extends StatelessWidget {
  final VoidCallback onTap;
  const CustomAppB({super.key, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: onTap, child: SvgPicture.asset(Assets.svgHelper('Arrow 2')));
  }
}
