abstract class Assets {
  static String helper(String image) => 'assets/icons/$image.png';
  static String svgHelper(String image) => 'assets/icons/$image.svg';
}
