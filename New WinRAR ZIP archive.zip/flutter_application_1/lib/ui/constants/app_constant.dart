import 'package:flutter_screenutil/flutter_screenutil.dart';

double height = 852.h;
double width = 393.w;

const Duration veryLongDuration = Duration(seconds: 3);

String kAppName = 'Dating App';
String firstPage = 'Find your';

String pageOne =
    'Application aimed at singles looking for serious relationship';
String pageTwo =
    'Our algorithm helps you find people with music, anime and book interest  as you';
String pageThree =
    'Meet and chat with people in your city that are open for friendship and relationship';

String pageTwoText = 'Make new friends, Find Love.';
String pageThreeSubText = 'Connect with people in your city';
String loginText = 'Log into your account';
String signupText = 'Create an account';
String otpText(String email) => 'Enter 4 digit code sent to $email';
