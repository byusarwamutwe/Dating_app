import 'package:flutter/material.dart';

BorderRadius get kminiBorderRadius => BorderRadius.circular(4);
BorderRadius get ksmallBorderRadius => BorderRadius.circular(6);
BorderRadius get knormalBorderRadius => BorderRadius.circular(10);
BorderRadius get kmediumBorderRadius => BorderRadius.circular(12);
BorderRadius get kminiMediumBorderRadius => BorderRadius.circular(14);
BorderRadius get miniMediumBorderRadius => BorderRadius.circular(16);
BorderRadius get largeMediumBorderRadius => BorderRadius.circular(18);
BorderRadius get largeBorderRadius => BorderRadius.circular(20);
BorderRadius get klargeBorderRadius => BorderRadius.circular(25);
