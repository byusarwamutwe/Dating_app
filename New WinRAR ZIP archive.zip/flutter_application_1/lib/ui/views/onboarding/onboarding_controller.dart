//import 'package:flutter_application_1/app/app_logger.dart';
import 'package:flutter_application_1/app/data/app_route.dart' as routes;
import 'package:flutter_application_1/bloc/onboarding/onboarding_bloc.dart';
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/views/onboarding/page_one/page_one.dart';
import 'package:flutter_application_1/ui/views/onboarding/page_three/page_three.dart';
import 'package:flutter_application_1/ui/views/onboarding/page_two/page_two.dart';
import 'package:flutter_application_1/ui/views/stateless_view/stateless_view.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

part 'onboarding.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => OnBoardingController();
}

class OnBoardingController extends State<OnBoardingScreen> {
  final NavigationService _navigationService = locator<NavigationService>();
  late PageController pageController;

  @override
  void initState() {
    super.initState();
    pageController = PageController();
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  loginPage() {
    _navigationService.goTo(routes.login);
  }

  @override
  Widget build(BuildContext context) {
    return OnBoarding(this);
  }
}
