import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/widget_extension.dart';
import 'package:flutter_application_1/ui/utils/asset_manager.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/material.dart';

import 'widget/image_spinner.dart';

class PageOne extends StatelessWidget {
  const PageOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // const HeightSpacer(size: 20),
              ReusableText(
                text: kAppName,
                style: appBStyle(
                  16,
                  Color(kDark.value),
                  FontWeight.w500,
                ),
              ),
              const HeightSpacer(size: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ReusableText(
                    text: firstPage,
                    style: appBStyle(
                      27,
                      Color(kDark.value),
                      FontWeight.w600,
                    ),
                  ),
                  widthSpacer(10),
                  ReusableText(
                    text: 'perfect',
                    style: appBStyle(
                      27,
                      Color(kDarkRed.value),
                      FontWeight.w600,
                    ),
                  ),
                ],
              ),
              ReusableText(
                text: 'partner',
                style: appBStyle(
                  27,
                  Color(kDark.value),
                  FontWeight.w600,
                ),
              ),
              const HeightSpacer(size: 30),
              Image.asset(
                Assets.helper('logo'),
                height: 40.h,
              ),
              const HeightSpacer(size: 10),
              const ImageSpinner(),
              const HeightSpacer(size: 30),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                child: ReusableText(
                  text: pageOne,
                  style: appMStyle(
                    18,
                    Color(kDark.value),
                    FontWeight.w500,
                  ),
                ),
              ),
              const HeightSpacer(size: 50),
            ],
          ),
        ),
      ),
    );
  }
}