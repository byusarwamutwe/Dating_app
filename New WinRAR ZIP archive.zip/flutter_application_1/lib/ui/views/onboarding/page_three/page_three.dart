import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/exports.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/material.dart';

class PageThree extends StatelessWidget {
  const PageThree({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/icons/people-with-smartphone.png',
            height: height * 0.4,
            width: width,
          ),
          const HeightSpacer(size: 30),
          ReusableText(
            text: pageThreeSubText,
            style: appMStyle(
              19,
              Color(kDark.value),
              FontWeight.w600,
            ),
          ),
          const HeightSpacer(size: 10),
          ReusableText(
            text: pageThree,
            style: appMStyle(
              19,
              Color(kDark.value),
              FontWeight.w500,
            ),
          ).padding(EdgeInsets.symmetric(horizontal: 20)),
        ],
      ),
    );
  }
}
