part of 'otp_controller.dart';

class OtpView extends StatelessView<OtpScreen, OtpController> {
  const OtpView(OtpController state, {Key? key}) : super(state, key: key);

  @override
  Widget build(BuildContext context) {
    Log.info('otp view');
    return Scaffold(
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppB(onTap: () {}),
          HeightSpacer(size: 20),
          Center(
            child: Column(
              children: [
                ReusableText(
                    text: 'Email Verification',
                    style: appMStyle(23, Color(kDark.value), FontWeight.w700)),
                HeightSpacer(size: 40),
                SvgPicture.asset(Assets.svgHelper('lock_color')),
                ReusableText(
                    text: 'Enter OTP',
                    style: appMStyle(23, Color(kDark.value), FontWeight.w600)),
                HeightSpacer(size: 20),
                ReusableText(
                    text: otpText('${widget.email}'),
                    style: appMStyle(20, Color(kGrey.value), FontWeight.w600)),
                HeightSpacer(size: 15),
                ReusableText(
                    text: 'Wrong email',
                    style: appMStyle(13, Color(kGrey.value), FontWeight.w400)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    buildField(context),
                    WidthSpacer(size: 5),
                    buildField(context),
                    WidthSpacer(size: 5),
                    buildField(context),
                    WidthSpacer(size: 5),
                    buildField(context),
                  ],
                ).padding(EdgeInsets.all(20))
              ],
            ),
          ),
          HeightSpacer(size: 10),
          buildTimer(),
        ],
      ).padding(EdgeInsets.symmetric(horizontal: 18, vertical: 20))),
    );
  }

  Widget buildField(BuildContext context) {
    return Expanded(
      child: TextFormField(
        onChanged: (value) {
          if (value.length == 1) {
            FocusScope.of(context).nextFocus();
          } else if (value.length == 3) {
            return;
          }
        },
        onSaved: (saved) {},
        autofocus: true,
        style: TextStyle(fontSize: 18),
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          fillColor: Color(kLowRed.value),
          filled: true,
          contentPadding: EdgeInsets.all(6.w),
          enabledBorder: OutlineInputBorder(
            borderRadius: knormalBorderRadius,
            borderSide: BorderSide(color: Color(kDarkGrey.value)),
          ),
          border: OutlineInputBorder(
            borderRadius: knormalBorderRadius,
            borderSide: BorderSide(color: Color(kDarkGrey.value)),
          ),
        ),
        inputFormatters: [
          LengthLimitingTextInputFormatter(1),
          FilteringTextInputFormatter.digitsOnly,
        ],
      ),
    );
  }

  Widget buildTimer() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () {
            // OTP code resend
          },
          child: Text('Resend code in '),
        ),
        TweenAnimationBuilder(
          tween: Tween(begin: 60.0, end: 0.0),
          duration: const Duration(seconds: 60),
          builder: (_, dynamic value, child) {
            return Text(
              "00:${value.toInt()} seconds",
              style: TextStyle(
                color: Color(kDark.value),
              ),
            );
          },
        ),
      ],
    ).padding(EdgeInsets.symmetric(horizontal: 20));
  }
}
