import 'package:flutter_application_1/app/app_logger.dart';
import 'package:flutter_application_1/app/exports.dart';
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/onpadding.dart';
import 'package:flutter_application_1/ui/utils/asset_manager.dart';
import 'package:flutter_application_1/ui/views/stateless_view/stateless_view.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/services.dart';

part 'otp_view.dart';

class OtpScreen extends StatefulWidget {
  final String email;
  const OtpScreen({super.key, required this.email});

  @override
  State<OtpScreen> createState() => OtpController();
}

class OtpController extends State<OtpScreen> {
  //final NavigationService _navigationService = locator<NavigationService>();
  late TextEditingController otpController;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    otpController = TextEditingController();
  }

  @override
  void dispose() {
    otpController.dispose();
    super.dispose();
  }

  homepage() {}

  @override
  Widget build(BuildContext context) {
    return OtpView(this);
  }
}
