import 'package:flutter_application_1/app/data/app_route.dart' as routes;
import 'package:flutter_application_1/app/exports.dart';
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/onpadding.dart';
import 'package:flutter_application_1/ui/utils/validation_manager.dart';
import 'package:flutter_application_1/ui/views/stateless_view/stateless_view.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/gestures.dart';

part 'signup_view.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => SignupController();
}

class SignupController extends State<SignUpScreen> {
  final NavigationService _navigationService = locator<NavigationService>();
  late TextEditingController emailController,
      passwordController,
      firstNameController,
      lastNameController;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    emailController = TextEditingController();
    passwordController = TextEditingController();
    firstNameController = TextEditingController();
    lastNameController = TextEditingController();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    super.dispose();
  }

  loginPage() {
    _navigationService.navigateTo(routes.login);
  }

  signup() {
    _navigationService.navigateTo(routes.otp, arguments: 'wobdele@gmail.com');
  }

  backPage() {
    _navigationService.goBack();
  }

  @override
  Widget build(BuildContext context) {
    return SignUpView(this);
  }
}
