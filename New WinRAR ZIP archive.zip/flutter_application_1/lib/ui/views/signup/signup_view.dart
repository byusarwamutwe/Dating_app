part of 'signup_controller.dart';

class SignUpView extends StatelessView<SignUpScreen, SignupController> {
  const SignUpView(SignupController state, {Key? key}) : super(state, key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomAppB(onTap: () => controller.backPage()),
              HeightSpacer(size: 30),
              ReusableText(
                  text: signupText,
                  style: appMStyle(23, Color(kDark.value), FontWeight.w700)),
              HeightSpacer(size: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: CustomTxtField(
                      labelText: 'First Name',
                      hintText: 'Enter first name',
                      keyboardType: TextInputType.name,
                      inputController: controller.firstNameController,
                      validator: (val) {
                        if (!val!.isValidName) return 'Enter a correct name';
                        return null;
                      },
                    ),
                  ),
                  WidthSpacer(size: 10),
                  Expanded(
                    child: CustomTxtField(
                      labelText: 'Last name',
                      hintText: 'Enter last name',
                      keyboardType: TextInputType.text,
                      inputController: controller.lastNameController,
                      validator: (val) {
                        if (!val!.isValidName)
                          return 'Enter a correct last name';
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              CustomTxtField(
                labelText: 'Email',
                hintText: 'Enter email',
                keyboardType: TextInputType.emailAddress,
                inputController: controller.emailController,
                validator: (val) {
                  if (!val!.isValidEmail) return 'Enter valid email';
                  return null;
                },
              ),
              HeightSpacer(size: 10),
              CustomTxtField(
                labelText: 'Password',
                hintText: 'Enter pasword',
                keyboardType: TextInputType.text,
                suffixIcon: true,
                inputController: controller.passwordController,
                validator: (val) {
                  if (!val!.isValidPassword) return 'incorrect password';
                  return null;
                },
              ),
              HeightSpacer(size: 30),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                        text: 'By signing up you agreed to our ',
                        style:
                            appMStyle(15, Color(kDark.value), FontWeight.w400)),
                    TextSpan(
                        text: 'Terms & condition ',
                        style: appMStyle(
                            15, Color(kDarkRed.value), FontWeight.w400),
                        recognizer: TapGestureRecognizer()..onTap = () {}),
                    TextSpan(
                      text: 'and ',
                      style: appMStyle(15, Color(kDark.value), FontWeight.w400),
                    ),
                    TextSpan(
                        text: 'privacy policy',
                        style: appMStyle(
                            15, Color(kDarkRed.value), FontWeight.w400),
                        recognizer: TapGestureRecognizer()..onTap = () {}),
                  ],
                ),
              ),
              HeightSpacer(size: 50),
              CustomBtn(
                width: width,
                height: height / 15,
                color: Color(kDarkRed.value),
                textColor: Color(kLight.value),
                text: 'Continue',
                onTap: () => controller.signup(),
              ),
              HeightSpacer(size: 50),
              Center(
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                          text: 'Already have an account? ',
                          style: appMStyle(
                              15, Color(kDarkGrey.value), FontWeight.w400)),
                      TextSpan(
                        text: 'Log in',
                        style: appMStyle(
                            15, Color(kDarkRed.value), FontWeight.w400),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => controller.loginPage(),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ).padding(EdgeInsets.symmetric(horizontal: 12, vertical: 20)),
        ),
      ),
    );
  }
}
