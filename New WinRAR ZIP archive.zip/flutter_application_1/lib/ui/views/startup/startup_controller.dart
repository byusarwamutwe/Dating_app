import 'package:flutter_application_1/app/data/app_route.dart' as routes;
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/onpadding.dart';
import 'package:flutter_application_1/ui/views/stateless_view/stateless_view.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/material.dart';

part 'startup.dart';

class StartupScreen extends StatefulWidget {
  const StartupScreen({super.key});

  @override
  State<StartupScreen> createState() => StartupController();
}

class StartupController extends State<StartupScreen> {
  final NavigationService _navigationService = locator<NavigationService>();

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 3)).whenComplete(() {
      _navigationService.goTo(routes.onboarding);
    });
    return Startup(this);
  }
}
