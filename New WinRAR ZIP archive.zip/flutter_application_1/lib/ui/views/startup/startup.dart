part of 'startup_controller.dart';

class Startup extends StatelessView<StartupScreen, StartupController> {
  const Startup(StartupController state, {Key? key}) : super(state, key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ReusableText(
            text: 'Welcome To Dating App',
            style: appMStyle(
              38.sp,
              Color(kDark.value),
              FontWeight.w500,
            ),
          ),
        ],
      ).padding(const EdgeInsets.symmetric(horizontal: 20)),
    );
  }
}
