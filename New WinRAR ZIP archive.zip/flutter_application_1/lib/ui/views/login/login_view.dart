part of './login_controller.dart';

class LoginView extends StatelessView<LoginScreen, LoginController> {
  const LoginView(LoginController state, {Key? key}) : super(state, key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              HeightSpacer(size: 30),
              ReusableText(
                  text: loginText,
                  style: appMStyle(23, Color(kDark.value), FontWeight.w700)),
              HeightSpacer(size: 30),
              CustomTxtField(
                labelText: 'Email',
                hintText: 'Email',
                keyboardType: TextInputType.emailAddress,
                inputController: controller.emailController,
                validator: (val) {
                  if (!val!.isValidEmail) return 'Enter valid email';
                  return null;
                },
              ),
              CustomTxtField(
                labelText: 'Password',
                hintText: 'Enter pasword',
                keyboardType: TextInputType.text,
                suffixIcon: true,
                inputController: controller.passwordController,
                validator: (val) {
                  if (!val!.isValidPassword) return 'incorrect password';
                  return null;
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ReusableText(
                      text: 'Remember me',
                      style:
                          appMStyle(15, Color(kDark.value), FontWeight.w400)),
                  ReusableText(
                      text: 'Forgot Password',
                      style: appMStyle(13, Color(kDark.value), FontWeight.w400))
                ],
              ),
              HeightSpacer(size: 30),
              CustomBtn(
                width: width,
                height: height / 15,
                color: Color(kDarkRed.value),
                textColor: Color(kLight.value),
                text: 'Login',
              ),
              HeightSpacer(size: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Divider(
                    color: Color(kDarkGrey.value),
                    thickness: 5,
                  ),
                  ReusableText(
                      text: 'or continue with',
                      style: appMStyle(
                          13, Color(kDarkGrey.value), FontWeight.w400)),
                  Divider(color: Color(kDarkGrey.value)),
                ],
              ),
              HeightSpacer(size: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  buildLoginOptions(onTap: () {}, imagePath: 'fb'),
                  WidthSpacer(size: 20),
                  buildLoginOptions(onTap: () {}, imagePath: 'gb'),
                  WidthSpacer(size: 20),
                  buildLoginOptions(onTap: () {}, imagePath: 'in'),
                ],
              ),
              HeightSpacer(size: 50),
              Center(
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                          text: 'Don\'t have an account? ',
                          style: appMStyle(
                              15, Color(kDarkGrey.value), FontWeight.w400)),
                      TextSpan(
                          text: 'Sign up',
                          style: appMStyle(
                              15, Color(kDarkRed.value), FontWeight.w400),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () => controller.signupPage()),
                    ],
                  ),
                ),
              ),
            ],
          ).padding(EdgeInsets.symmetric(vertical: 30, horizontal: 10)),
        ),
      ),
    );
  }

  Widget buildLoginOptions(
      {required VoidCallback onTap,
      required String imagePath,
      double? height}) {
    return GestureDetector(
      onTap: onTap,
      child: Image.asset(
        Assets.helper(imagePath),
        height: height,
      ),
    );
  }
}
