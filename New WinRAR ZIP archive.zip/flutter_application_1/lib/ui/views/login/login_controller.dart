import 'package:flutter_application_1/app/data/app_route.dart' as routes;
import 'package:flutter_application_1/app/exports.dart';
import 'package:flutter_application_1/ui/constants/exports.dart';
import 'package:flutter_application_1/ui/extensions/exports.dart';
import 'package:flutter_application_1/ui/utils/asset_manager.dart';
import 'package:flutter_application_1/ui/utils/validation_manager.dart';
import 'package:flutter_application_1/ui/views/stateless_view/stateless_view.dart';
import 'package:flutter_application_1/ui/widgets/exports.dart';
import 'package:flutter/gestures.dart';

part 'login_view.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => LoginController();
}

class LoginController extends State<LoginScreen> {
  late TextEditingController emailController, passwordController;
  final NavigationService _navigationService = locator<NavigationService>();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    emailController = TextEditingController();
    passwordController = TextEditingController();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  signupPage() {
    _navigationService.navigateTo(routes.signup);
  }

  @override
  Widget build(BuildContext context) {
    return LoginView(this);
  }
}
