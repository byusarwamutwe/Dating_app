import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

extension OnTextExtension on Widget {
  Widget reusableText(String text, {required TextStyle style}) {
    return Text(text, style: style);
  }
}

extension OnWidthSpacer on Widget {
  Widget widthSpacer(double width) {
    return SizedBox(width: width.w);
  }
}

extension OnHeightSpacer on Widget {
  Widget heightSpacer(double height) {
    return SizedBox(width: height.h);
  }
}

extension OnCenter on Widget {
  Widget center() {
    return Center();
  }
}
